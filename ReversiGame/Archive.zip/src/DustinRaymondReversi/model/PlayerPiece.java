package DustinRaymondReversi.model;

/**
 * Represents of two different player entities in the game.
 */
public enum PlayerPiece {
  PLAYER_ONE,
  PLAYER_TWO;
}