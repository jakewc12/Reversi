package adaptation_assignment;

public class PlayerPieceToPlayer {
}
